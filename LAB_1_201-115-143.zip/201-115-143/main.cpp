#include <GL/glut.h>

void drawWindow(float x, float y) {
    glBegin(GL_QUADS);
    glColor3f(0.9f, 0.9f, 0.9f);
    glVertex3f(x - 0.1f, y - 0.1f, 0.0f);
    glVertex3f(x + 0.1f, y - 0.1f, 0.0f);
    glVertex3f(x + 0.1f, y + 0.1f, 0.0f);
    glVertex3f(x - 0.1f, y + 0.1f, 0.0f);
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Draw the base
    glBegin(GL_QUADS);
    glColor3f(0.5f, 0.5f, 0.5f);
    glVertex3f(-1.0f, -1.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, 0.0f);
    glVertex3f(1.0f, 1.0f, 0.0f);
    glVertex3f(-1.0f, 1.0f, 0.0f);
    glEnd();

    // Draw the roof
    glBegin(GL_TRIANGLES);
    glColor3f(0.8f, 0.2f, 0.2f);
    glVertex3f(-1.0f, 1.0f, 0.0f);
    glVertex3f(0.0f, 2.0f, 0.0f);
    glVertex3f(1.0f, 1.0f, 0.0f);
    glEnd();

    // Draw the door
    glBegin(GL_QUADS);
    glColor3f(0.2f, 0.4f, 0.8f);
    glVertex3f(-0.2f, -1.0f, 0.0f);
    glVertex3f(0.2f, -1.0f, 0.0f);
    glVertex3f(0.2f, 0.0f, 0.0f);
    glVertex3f(-0.2f, 0.0f, 0.0f);
    glEnd();

    // Draw windows
    drawWindow(-0.5f, 0.5f);
    drawWindow(0.5f, 0.5f);
    drawWindow(-0.5f, -0.5f);
    drawWindow(0.5f, -0.5f);

    glFlush();
}

void reshape(int width, int height) {
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-2.0, 2.0, -2.0, 2.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1200, 800);
    glutCreateWindow("House Example with Windows");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

    glutMainLoop();
    return 0;
}
